"""Reduced-budget protocol actually executed in the delivered results (single CPU core).
Differences to the paper protocol are only in the number of seeds at N=50 and the MILP time limit."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stbj_hum import experiments as X
from stbj_hum.params import GenParams
root = os.path.dirname(os.path.abspath(__file__))
insts = X.make_instances(root)
steps = sys.argv[1].split(",")
for e in steps:
    t = time.time(); print("=== START", e, flush=True)
    if e == "E3": X.E3_stability(root, insts, N=35, n_runs=15)
    if e == "E1": X.E1_validation(root, insts, n_seeds=5, milp_time=300)
    if e == "E2": X.E2_baselines(root, insts, n_seeds=3, seeds_by_N={50: 1})
    if e == "E7": X.E7_sensitivity(root, insts, N=35, n_seeds=2)
    if e == "E4": X.E4_ablation(root, insts, n_seeds=3, seeds_by_N={50: 1})
    if e == "E5b":
        ii = X.make_instances(root, sizes=(20, 35, 50), gp=GenParams(win_len=48.0), tag="_win48")
        X.E5_joint_vs_sequential(root, ii, tag="_win48", n_seeds=2, seeds_by_N={50: 1})
    if e == "E4b": X.E4b_time_to_target(root, insts, sizes=(20, 35), n_seeds=2)
    print("=== END", e, round(time.time() - t), "s", flush=True)
