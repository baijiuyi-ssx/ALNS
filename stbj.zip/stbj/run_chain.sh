#!/bin/bash
cd /home/claude/stbj
for E in E5 E6 E2 E4 E3 E7 E4b E1; do
  echo "=== START $E $(date)" >> results/run_log.txt
  python3 run_all.py --only $E --milp_time 400 >> results/run_log.txt 2>&1
  echo "=== END $E $(date)" >> results/run_log.txt
done
echo "=== START E5b $(date)" >> results/run_log.txt
python3 -c "
import sys; sys.path.insert(0,'.')
from stbj_hum import experiments as X
from stbj_hum.params import GenParams
insts = X.make_instances('.', sizes=(20,35,50), gp=GenParams(win_len=48.0), tag='_win48')
X.E5_joint_vs_sequential('.', insts, tag='_win48')
" >> results/run_log.txt 2>&1
echo "=== END E5b $(date)" >> results/run_log.txt
