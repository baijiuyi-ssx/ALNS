"""
Run the full computational study (E1-E7) of the STBJ-HUM paper.
Usage:  python run_all.py [--quick] [--only E1,E2,...]
Outputs: data/instances/*.json, results/*.csv, figures/*.png
"""
import sys, os, argparse, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stbj_hum import experiments as X

ap = argparse.ArgumentParser()
ap.add_argument("--quick", action="store_true", help="reduced seeds/sizes for a fast check")
ap.add_argument("--only", default="", help="comma list, e.g. E1,E5")
ap.add_argument("--milp_time", type=float, default=900.0)
args = ap.parse_args()
root = os.path.dirname(os.path.abspath(__file__))
only = set(args.only.split(",")) if args.only else None
def want(e): return only is None or e in only

t0 = time.time()
insts = X.make_instances(root)
ns = 1 if args.quick else None
if want("E1"): X.E1_validation(root, insts, sizes=(5, 8, 10, 15) if args.quick else (5, 8, 10, 15, 20), n_seeds=ns or 5, milp_time=args.milp_time)
if want("E2"): X.E2_baselines(root, insts, sizes=(10, 20) if args.quick else (10, 15, 20, 35, 50), n_seeds=ns or 3)
if want("E3"): X.E3_stability(root, insts, N=35, n_runs=3 if args.quick else 15)
if want("E4"): X.E4_ablation(root, insts, sizes=(20,) if args.quick else (20, 35, 50), n_seeds=ns or 3)
if want("E4b"): X.E4b_time_to_target(root, insts, sizes=(20,) if args.quick else (20, 35, 50), n_seeds=ns or 3)
if want("E5"): X.E5_joint_vs_sequential(root, insts, sizes=(20,) if args.quick else (20, 35, 50), n_seeds=ns or 3)
if want("E6"): X.E6_layouts(root, sizes=(20,) if args.quick else (20, 35, 50), n_seeds=ns or 3)
if want("E7"): X.E7_sensitivity(root, insts, N=35, n_seeds=ns or 3)
print("ALL DONE in", round(time.time()-t0), "s")
