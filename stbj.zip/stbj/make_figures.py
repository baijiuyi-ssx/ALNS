"""Draw Fig. 2-6 analogues from results/*.csv into figures/*.png."""
import os, sys
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = os.path.dirname(os.path.abspath(__file__))
R = lambda f: os.path.join(root, "results", f)
F = lambda f: os.path.join(root, "figures", f)
os.makedirs(F(""), exist_ok=True)

# Fig. 2: E2 baseline gaps by N
if os.path.exists(R("E2_baselines_raw.csv")):
    df = pd.read_csv(R("E2_baselines_raw.csv"))
    g = df.groupby("N")[[f"gap_{a}_pct" for a in ("Vanilla_ALNS", "TS", "SA", "GA")]].mean()
    ax = g.plot(marker="o", figsize=(6, 4))
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xlabel("Instance size N"); ax.set_ylabel("Mean gap to ALNS-STB (%)")
    ax.set_title("E2: baselines under equal time budgets")
    ax.legend([c.replace("gap_", "").replace("_pct", "") for c in g.columns])
    plt.tight_layout(); plt.savefig(F("Fig2_E2_baseline_gaps.png"), dpi=200); plt.close()

# Fig. 3: E3 convergence + spread
if os.path.exists(R("E3_traces.csv")):
    tr = pd.read_csv(R("E3_traces.csv"), index_col=0)/1e6
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].fill_between(tr.index, tr.min(axis=1), tr.max(axis=1), alpha=0.25, label="Min-max over runs")
    ax[0].plot(tr.index, tr.mean(axis=1), label="Mean incumbent")
    ax[0].set_xlabel("Iteration"); ax[0].set_ylabel("Best cost (10^6 USD)"); ax[0].set_title("(a) Incumbent trajectory, N = 35"); ax[0].legend()
    finals = tr.iloc[-1]
    ax[1].hist(finals, bins=8, edgecolor="g", alpha=0.5)
    ax[1].axvline(finals.mean(), ls="--", color="r", label=f"Mean = {finals.mean():.3f}")
    ax[1].set_xlabel("Final cost (10^6 USD)"); ax[1].set_ylabel("Runs")
    ax[1].set_title(f"(b) Final-cost spread (CV = {100*finals.std()/finals.mean():.2f}%)"); ax[1].legend()
    plt.tight_layout(); plt.savefig(F("Fig3_E3_convergence.png"), dpi=200); plt.close()

# Fig. 4: E5 joint vs sequential
if os.path.exists(R("E5_sequential_raw.csv")):
    df = pd.read_csv(R("E5_sequential_raw.csv"))
    cols = ["typefirst_total_pct", "typefirst_ctrl_pct", "berthfirst_total_pct", "berthfirst_ctrl_pct"]
    m = df.groupby("N")[cols].mean(); s = df.groupby("N")[cols].std()
    ax = m.plot.bar(yerr=s, figsize=(7, 4), capsize=3)
    ax.set_ylabel("Cost increase vs joint (%)"); ax.set_title("E5: penalty of sequential planning")
    plt.tight_layout(); plt.savefig(F("Fig4_E5_sequential_penalty.png"), dpi=200); plt.close()

# Fig. 5: E6 layouts
if os.path.exists(R("E6_layouts_summary.csv")):
    df = pd.read_csv(R("E6_layouts_summary.csv"))
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
    df["label"] = df["window_h"].astype(str) + "h/N=" + df["N"].astype(str)
    df.set_index("label")[["cost_7V+3S", "cost_7V+0S", "cost_10V+0S"]].div(1e6).plot.bar(ax=ax[0])
    ax[0].set_ylabel("Total cost (10^6 USD)"); ax[0].set_title("(a) Cost by layout")
    df.set_index("label")[["wait_7V+3S", "wait_7V+0S", "wait_10V+0S"]].plot.bar(ax=ax[1])
    ax[1].set_ylabel("Total waiting (h)"); ax[1].set_title("(b) Waiting by layout")
    plt.tight_layout(); plt.savefig(F("Fig5_E6_layouts.png"), dpi=200); plt.close()

# Fig. 6: E7 sensitivity
if os.path.exists(R("E7_sensitivity_raw.csv")):
    df = pd.read_csv(R("E7_sensitivity_raw.csv"))
    ax = df.pivot(index="scale", columns="parameter", values="change_pct").plot(marker="o", figsize=(6, 4))
    ax.axhline(0, color="k", lw=0.8); ax.set_xlabel("Scaling factor"); ax.set_ylabel("Change in optimized total cost (%)")
    ax.set_title("E7: cost-parameter sensitivity, N = 35")
    plt.tight_layout(); plt.savefig(F("Fig6_E7_sensitivity.png"), dpi=200); plt.close()

# E1 gaps
if os.path.exists(R("E1_validation.csv")):
    df = pd.read_csv(R("E1_validation.csv"))
    fig, ax = plt.subplots(figsize=(6, 3.8))
    x = range(len(df)); ax.bar([i-0.2 for i in x], df["gap_best_pct"], 0.4, label="best of 5")
    ax.bar([i+0.2 for i in x], df["gap_mean_pct"], 0.4, label="mean of 5")
    ax.set_xticks(list(x)); ax.set_xticklabels([f"N{n}-{i}" for n, i in zip(df["N"], df["instance"])], rotation=45)
    ax.set_ylabel("Gap to HiGHS optimum (%)"); ax.set_title("E1: ALNS-STB vs proven optima"); ax.legend()
    plt.tight_layout(); plt.savefig(F("Fig_E1_gaps.png"), dpi=200); plt.close()
print("figures written to", F(""))
