"""Build results/COMPARISON_paper_vs_reproduction.md from results/*.csv and data/paper_tables/*.csv."""
import os, pandas as pd
root = os.path.dirname(os.path.abspath(__file__))
R = lambda f: os.path.join(root, "results", f)
P = lambda f: os.path.join(root, "data/paper_tables", f)
out = []
def md(df, floatfmt="{:.3f}"):
    df = df.copy()
    for c in df.columns:
        if df[c].dtype.kind == "f":
            df[c] = df[c].map(lambda v: floatfmt.format(v) if pd.notna(v) else "")
    return df.to_markdown(index=False)

# E1
if os.path.exists(R("E1_validation.csv")):
    d = pd.read_csv(R("E1_validation.csv"))
    d["milp_opt"] = d["milp_status"].str.contains("Optimal")
    out.append("## E1 精确验证（论文表 3 vs 复现）\n")
    out.append("论文：best 缺口 ≤0.10%，mean 缺口均值 0.09%（最大 0.30%），7/10 命中最优，HiGHS N=20 需 105–197 s。\n")
    out.append(md(d[["N", "instance", "optimum_1e6", "milp_opt", "milp_time_s", "alns_best_1e6", "gap_best_pct", "gap_mean_pct", "alns_mean_time_s"]], "{:.4f}"))
    hit = (d["gap_best_pct"].abs() < 1e-6).sum()
    out.append(f"\n复现：命中最优 {hit}/{len(d)}；best 缺口最大 {d['gap_best_pct'].max():.4f}%；mean 缺口均值 {d['gap_mean_pct'].mean():.4f}%，最大 {d['gap_mean_pct'].max():.4f}%。\n")
# E2
if os.path.exists(R("E2_baselines_summary.csv")):
    d = pd.read_csv(R("E2_baselines_summary.csv"))
    out.append("## E2 等时基线（论文表 4 vs 复现）\n\n论文（均值%）：vanilla −0.01 (p=0.36)，TS +0.34，SA +0.57，GA +0.57，均 p<1e-8。\n")
    out.append(md(d, "{:.4g}"))
    out.append("")
# E3
if os.path.exists(R("E3_summary.csv")):
    d = pd.read_csv(R("E3_summary.csv"))
    out.append("## E3 稳定性（论文：CV 0.05%，spread 0.17%，1.8 s）\n")
    out.append(md(d, "{:.4f}")); out.append("")
# E4
if os.path.exists(R("E4_ablation_summary.csv")):
    d = pd.read_csv(R("E4_ablation_summary.csv"))
    out.append("## E4 消融（论文表 5：仅 regret-2 +0.21% p=0.001 与自适应权重 +0.08% p=0.009 显著）\n")
    out.append(md(d, "{:.3f}")); out.append("")
if os.path.exists(R("E4b_time_to_target_summary.csv")):
    d = pd.read_csv(R("E4b_time_to_target_summary.csv"))
    out.append("### E4b 达标迭代数（论文：HCL 中位数 40，随机 48，贪心 28；终解质量无差异）\n")
    out.append(md(d, "{:.3f}")); out.append("")
# E5
for tag, title in (("", "默认实例（48–168 h 窗口）"), ("_win48", "拥堵实例（48 h 窗口，补充）")):
    f = R(f"E5_sequential{tag}_raw.csv")
    if os.path.exists(f):
        d = pd.read_csv(f)
        cols = ["typefirst_total_pct", "typefirst_ctrl_pct", "berthfirst_total_pct", "berthfirst_ctrl_pct"]
        g = d.groupby("N")[cols].mean().reset_index()
        g["joint_util"] = d.groupby("N")["joint_util"].mean().values
        out.append(f"## E5 联合 vs 顺序 — {title}（论文表 6：N=50 type-first +1.90/+10.5%，berth-first +2.21/+10.0%）\n")
        out.append(md(g, "{:.3f}"))
        out.append(f"\n最大单次可控成本损失：type-first {d['typefirst_ctrl_pct'].max():.2f}%，berth-first {d['berthfirst_ctrl_pct'].max():.2f}%。\n")
# E6
if os.path.exists(R("E6_layouts_summary.csv")):
    d = pd.read_csv(R("E6_layouts_summary.csv"))
    d2 = d[["window_h", "N", "util_7V+3S", "cost_7V+3S", "cost_7V+0S", "cost_10V+0S", "wait_7V+3S", "wait_7V+0S", "wait_10V+0S", "lots_on_sloped", "saving_vs_7V0S_pct", "saving_vs_10V0S_pct", "wait_reduction_vs_7V0S_pct"]].copy()
    for c in ("cost_7V+3S", "cost_7V+0S", "cost_10V+0S"):
        d2[c] = d2[c]/1e6
    out.append("## E6 布局（论文表 7：7V+3S 比 7V+0S 省 0.6–7.5%、等待 −32–51%；比 10V+0S 省 0.4–4.0%）\n")
    out.append(md(d2, "{:.3f}")); out.append("")
# E7
if os.path.exists(R("E7_sensitivity_summary.csv")):
    d = pd.read_csv(R("E7_sensitivity_summary.csv"))
    out.append("## E7 灵敏度（论文表 8：弹性 0.441/0.408/0.139/0.008）\n")
    out.append(md(d, "{:.3f}")); out.append("")
open(R("COMPARISON_paper_vs_reproduction.md"), "w").write("\n".join(out))
print("\n".join(out))
