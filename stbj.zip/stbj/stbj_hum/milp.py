"""
Compact MILP of STBJ-HUM, Eq. (4)-(14), solved with HiGHS (scipy.optimize.milp).

Variables (columns):
    x[j,(k,b)]  binary, only for (k,b) in Phi_j          (three-index assignment)
    s_j, e_j, w_j, l_j  continuous
    e_jk        continuous copy of e_j active when class k chosen   (Eq. 10)
    z_jj'       binary sequencing (j departs before j' starts)      (Eq. 11-12)

Objective (4):
    sum_j [ sum_(k,b) (S_jk + U_jb) x_jkb + sum_k c_k/24 (e_jk - A_jk xbar_jk)
            + alpha_w w_j + pi l_j ]
Big-M = T_bound + 1 with T_bound >= any feasible completion time.
"""
from __future__ import annotations
import time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix
from .instance import Instance
from .solution import Solution


def solve_milp(inst: Instance, time_limit: float = 600.0, verbose: bool = False, mip_gap: float = 1e-6):
    N, K, B = inst.N, inst.K, inst.B
    Tb = inst.T_bound
    M = Tb + 1.0

    # ---- column indexing ----
    col = {}
    n = 0
    for j in range(N):
        for (k, b) in inst.Phi[j]:
            col[("x", j, k, b)] = n; n += 1
    for name in ("s", "e", "w", "l"):
        for j in range(N):
            col[(name, j)] = n; n += 1
    for j in range(N):
        for k in range(K):
            col[("ek", j, k)] = n; n += 1
    for j in range(N):
        for jp in range(N):
            if j != jp:
                col[("z", j, jp)] = n; n += 1
    nvar = n

    c = np.zeros(nvar)
    lb = np.zeros(nvar); ub = np.full(nvar, np.inf)
    integrality = np.zeros(nvar)
    for key, i in col.items():
        if key[0] in ("x", "z"):
            ub[i] = 1.0; integrality[i] = 1
        elif key[0] in ("s", "e", "ek"):
            ub[i] = Tb
        # w, l >= 0 unbounded above

    # ---- objective ----
    for j in range(N):
        for (k, b) in inst.Phi[j]:
            c[col[("x", j, k, b)]] += inst.S[j][k] + inst.U[j][b] - inst.c_h[k]*inst.A[j][k]
        for k in range(K):
            c[col[("ek", j, k)]] += inst.c_h[k]
        c[col[("w", j)]] += inst.alpha_w
        c[col[("l", j)]] += inst.pi

    rows = []   # (dict col->coef, lo, hi)
    def add(coefs, lo, hi):
        rows.append((coefs, lo, hi))

    for j in range(N):
        xj = [col[("x", j, k, b)] for (k, b) in inst.Phi[j]]
        # (5) assignment
        add({i: 1.0 for i in xj}, 1.0, 1.0)
        # (6) s_j - sum_k A_jk xbar_jk >= 0 ;  (7) w_j - s_j + sum A xbar = 0
        r6 = {col[("s", j)]: 1.0}
        r7 = {col[("w", j)]: 1.0, col[("s", j)]: -1.0}
        for (k, b) in inst.Phi[j]:
            i = col[("x", j, k, b)]
            r6[i] = r6.get(i, 0.0) - inst.A[j][k]
            r7[i] = r7.get(i, 0.0) + inst.A[j][k]
        add(r6, 0.0, np.inf)
        add(r7, 0.0, 0.0)
        # (8) e_j - s_j - sum_b T_jb y_jb = 0
        r8 = {col[("e", j)]: 1.0, col[("s", j)]: -1.0}
        for (k, b) in inst.Phi[j]:
            i = col[("x", j, k, b)]
            r8[i] = r8.get(i, 0.0) - inst.T[j][b]
        add(r8, 0.0, 0.0)
        # (9) l_j - e_j >= -D_j
        add({col[("l", j)]: 1.0, col[("e", j)]: -1.0}, -inst.lots[j].D, np.inf)
        # (10) e_jk - e_j - M xbar_jk >= -M
        for k in range(K):
            r10 = {col[("ek", j, k)]: 1.0, col[("e", j)]: -1.0}
            for (kk, b) in inst.Phi[j]:
                if kk == k:
                    i = col[("x", j, k, b)]
                    r10[i] = r10.get(i, 0.0) - M
            add(r10, -M, np.inf)
    # (11) s_j' - e_j + M z_jj' + M y_jb + M y_j'b <= 3M   (for all j != j', b)
    ybcols = [[[col[("x", j, k, bb)] for (k, bb) in inst.Phi[j] if bb == b] for b in range(B)] for j in range(N)]
    for j in range(N):
        for jp in range(N):
            if j == jp:
                continue
            for b in range(B):
                if not ybcols[j][b] or not ybcols[jp][b]:
                    continue
                r = {col[("s", jp)]: 1.0, col[("e", j)]: -1.0, col[("z", j, jp)]: -M}
                for i in ybcols[j][b]:
                    r[i] = r.get(i, 0.0) - M
                for i in ybcols[jp][b]:
                    r[i] = r.get(i, 0.0) - M
                # s_j' >= e_j - M(3 - z - y - y')  <=>  s_j' - e_j - M z - M y - M y' >= -3M
                add(r, -3.0*M, np.inf)
    # (12) z_jj' + z_j'j = 1
    for j in range(N):
        for jp in range(j+1, N):
            add({col[("z", j, jp)]: 1.0, col[("z", jp, j)]: 1.0}, 1.0, 1.0)

    A = lil_matrix((len(rows), nvar))
    lo = np.zeros(len(rows)); hi = np.zeros(len(rows))
    for ri, (coefs, l_, h_) in enumerate(rows):
        for i, v in coefs.items():
            A[ri, i] = v
        lo[ri] = l_; hi[ri] = h_
    cons = LinearConstraint(A.tocsr(), lo, hi)

    t0 = time.time()
    res = milp(c, constraints=cons, integrality=integrality, bounds=Bounds(lb, ub),
               options={"time_limit": time_limit, "disp": verbose, "mip_rel_gap": mip_gap})
    elapsed = time.time() - t0

    out = {"status": res.status, "message": res.message, "time_s": elapsed,
           "objective": None, "mip_gap": None, "n_binaries": int(integrality.sum()),
           "n_rows": len(rows), "solution": None}
    if res.x is not None:
        out["objective"] = float(res.fun)
        out["mip_gap"] = getattr(res, "mip_gap", None)
        sol = Solution(inst)
        for j in range(N):
            for (k, b) in inst.Phi[j]:
                if res.x[col[("x", j, k, b)]] > 0.5:
                    sol.ktype[j] = k; sol.berth[j] = b
        # sequence per berth by start time
        for b in range(B):
            lots_b = [j for j in range(N) if sol.berth[j] == b]
            lots_b.sort(key=lambda j: res.x[col[("s", j)]])
            sol.seq[b] = lots_b
        sol.decode()
        out["solution"] = sol
        out["decoded_total"] = sol.total   # semi-active re-decode (equals objective at optimum)
    return out
