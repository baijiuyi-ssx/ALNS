"""
ALNS-STB (Section 4, Algorithm 1) with all switches needed for the ablation
(Section 5.5) and for the vanilla-ALNS baseline (Section 5.3).

Algorithm 1
 1. x <- HCL construction; x* <- x; T <- 0.01 f(x)/ln 2
 2. operator weights w_i^d = w_i^r = 1
 3. for t = 1..I_max, I_max = min{2000, max{600, 40N}}
 4.   roulette-wheel selection of destroy d and repair r
 5.   x' <- r(d(x, q)),  q = ceil(0.2 N)
 6.   if f(x') < f(x*): x* <- x'; x <- x'
 7.   elif f(x') < f(x) or rand < exp(-(f(x')-f(x))/T): x <- x'
 8.   credit d, r with 50 / 10 / 3 (new best / improvement / accepted)
 9.   every 50 iterations: w_i <- max{0.1, 0.7 w_i + 0.3 mean score_i}
10.   T <- gamma T, gamma such that T(I_max) = 1e-4 f(x0)
"""
from __future__ import annotations
import math, random, time
from dataclasses import dataclass, field
from typing import List, Optional, Callable, Dict
from .instance import Instance
from .solution import Solution


@dataclass
class ALNSConfig:
    init: str = "hcl"                 # "hcl" | "random" | "greedy"
    destroy_ops: tuple = ("D1", "D2", "D3", "D4")
    repair_ops: tuple = ("R1", "R2", "R3")
    sa_acceptance: bool = True
    adaptive_weights: bool = True
    lam: float = 0.5                  # HCL random share
    u0: float = 0.7                   # logistic map seed
    q_frac: float = 0.2
    max_iter: Optional[int] = None    # default min{2000, max{600, 40N}}
    time_limit: Optional[float] = None
    scores: tuple = (50.0, 10.0, 3.0)
    segment: int = 50
    reaction: float = 0.3
    w_min: float = 0.1
    T0_frac: float = 0.01
    Tend_frac: float = 1e-4
    fixed_types: Optional[List[int]] = None   # E5 type-first: classes frozen
    fixed_berths: Optional[List[int]] = None  # E5 berth-first: berths frozen
    record_trace: bool = False

VANILLA = ALNSConfig(init="random", destroy_ops=("D2", "D3"), repair_ops=("R1", "R3"))


def default_iters(N: int) -> int:
    return min(2000, max(600, 40*N))


# ======================================================================
class ALNS_STB:
    def __init__(self, inst: Instance, cfg: ALNSConfig = None, seed: int = 0):
        self.inst = inst
        self.cfg = cfg or ALNSConfig()
        self.rng = random.Random(seed)
        self.u = self.cfg.u0   # logistic map state
        self.trace: List[float] = []
        self.stats: Dict = {}

    # ---------------- chaos ----------------
    def chaos(self) -> float:
        self.u = 4.0*self.u*(1.0 - self.u)
        # keep away from the fixed points 0 and 0.75 numerically
        if self.u <= 1e-9 or self.u >= 1 - 1e-9:
            self.u = 0.7
        return self.u

    # ---------------- feasible choices ----------------
    def feasible_classes(self, j: int) -> List[int]:
        if self.cfg.fixed_types is not None:
            return [self.cfg.fixed_types[j]]
        if self.cfg.fixed_berths is not None:
            b = self.cfg.fixed_berths[j]
            return [k for (k, bb) in self.inst.Phi[j] if bb == b]
        return self.inst.feas_k[j]

    def feasible_berths(self, j: int, k: int) -> List[int]:
        if self.cfg.fixed_berths is not None:
            return [self.cfg.fixed_berths[j]]
        return self.inst.feas_b_given_k[j][k]

    # ---------------- 4.1 HCL construction ----------------
    def construct(self, mode: Optional[str] = None) -> Solution:
        inst, rng, cfg = self.inst, self.rng, self.cfg
        mode = mode or cfg.init
        sol = Solution(inst)
        for j in range(inst.N):
            ks = self.feasible_classes(j)
            # Layer 1: class
            if mode == "random":
                k = rng.choice(ks)
            elif mode == "greedy":
                k = min(ks, key=lambda kk: inst.S[j][kk])
            else:  # hcl
                if rng.random() < cfg.lam:
                    k = rng.choice(ks)
                else:
                    smin = min(inst.S[j][kk] for kk in ks)
                    weights = [(smin/inst.S[j][kk])**2 * (0.5 + self.chaos()) for kk in ks]
                    k = rng.choices(ks, weights=weights)[0]
            # Layer 2: berth
            bs = self.feasible_berths(j, k)
            if mode == "random":
                b = rng.choice(bs)
            elif mode == "greedy":
                b = min(bs, key=lambda bb: inst.U[j][bb] + inst.c_h[k]*inst.T[j][bb])
            else:
                if rng.random() < cfg.lam:
                    b = rng.choice(bs)
                else:
                    weights = [inst.berths[bb].r * (0.5 + self.chaos()) for bb in bs]
                    b = rng.choices(bs, weights=weights)[0]
            sol.ktype[j] = k; sol.berth[j] = b
        # Layer 3: FCFS by arrival on each berth
        for b in range(inst.B):
            lots = [j for j in range(inst.N) if sol.berth[j] == b]
            lots.sort(key=lambda j: inst.A[j][sol.ktype[j]])
            sol.seq[b] = lots
        sol.decode()
        return sol

    # ---------------- 4.2 destroy operators ----------------
    def destroy(self, op: str, sol: Solution, q: int) -> List[int]:
        inst, rng = self.inst, self.rng
        N = inst.N
        if op == "D1":   # time similarity around a seed lot
            seed = rng.randrange(N)
            a0 = inst.A[seed][sol.ktype[seed]]
            order = sorted(range(N), key=lambda j: abs(inst.A[j][sol.ktype[j]] - a0))
            removed = order[:q]
        elif op == "D2":  # random
            removed = rng.sample(range(N), q)
        elif op == "D3":  # worst cost (individual cost contributions)
            order = sorted(range(N), key=lambda j: -sol.lot_cost[j])
            removed = order[:q]
        elif op == "D4":  # congestion-aware: berth with largest accumulated waiting
            bstar = max(range(inst.B), key=lambda b: sol.berth_wait[b])
            cand = sol.seq[bstar][:]
            if sol.berth_wait[bstar] <= 0.0:
                cand = rng.sample(range(N), q)  # no queue anywhere: fall back to random
            removed = cand[:q] if len(cand) >= q else cand
            # "evicts up to q of its lots": if the bottleneck berth holds fewer
            # than q lots, top up randomly so that the removal size is honoured
            if len(removed) < q:
                pool = [j for j in range(N) if j not in removed]
                removed += rng.sample(pool, q - len(removed))
        else:
            raise ValueError(op)
        for j in removed:
            sol.remove_lot(j)
        return removed

    # ---------------- 4.2 repair operators ----------------
    def _best_two(self, sol: Solution, j: int):
        """Best and second-best (delta, k, b, pos) triple for lot j."""
        best = (float("inf"), -1, -1, -1); second = (float("inf"), -1, -1, -1)
        for k in self.feasible_classes(j):
            for b in self.feasible_berths(j, k):
                seq = sol.seq[b]
                for pos in range(len(seq)+1):
                    d = sol.insertion_delta(j, k, b, pos)
                    if d < best[0]:
                        second = best; best = (d, k, b, pos)
                    elif d < second[0]:
                        second = (d, k, b, pos)
        return best, second

    def repair(self, op: str, sol: Solution, removed: List[int]):
        rng = self.rng
        if op == "R1":   # greedy, random order
            order = removed[:]; rng.shuffle(order)
            for j in order:
                best, _ = self._best_two(sol, j)
                sol.insert_lot(j, best[1], best[2], best[3])
        elif op == "R2":  # random feasible triple
            for j in removed:
                k = rng.choice(self.feasible_classes(j))
                b = rng.choice(self.feasible_berths(j, k))
                pos = rng.randint(0, len(sol.seq[b]))
                sol.insert_lot(j, k, b, pos)
        elif op == "R3":  # regret-2
            pending = removed[:]
            while pending:
                best_j = None; best_regret = -1.0; best_ins = None
                for j in pending:
                    b1, b2 = self._best_two(sol, j)
                    regret = (b2[0] - b1[0]) if b2[0] < float("inf") else float("inf")
                    if regret > best_regret:
                        best_regret = regret; best_j = j; best_ins = b1
                sol.insert_lot(best_j, best_ins[1], best_ins[2], best_ins[3])
                pending.remove(best_j)
        else:
            raise ValueError(op)

    # ---------------- Algorithm 1 ----------------
    def run(self, x0: Optional[Solution] = None) -> Solution:
        inst, cfg, rng = self.inst, self.cfg, self.rng
        N = inst.N
        I_max = cfg.max_iter or default_iters(N)
        q = max(1, math.ceil(cfg.q_frac*N))
        t_start = time.time()

        x = x0.copy() if x0 is not None else self.construct()
        f0 = x.total
        best = x.copy()
        T = cfg.T0_frac*f0/math.log(2.0)
        T_end = cfg.Tend_frac*f0
        gamma = (T_end/T)**(1.0/I_max)

        dops, rops = list(cfg.destroy_ops), list(cfg.repair_ops)
        wd = {o: 1.0 for o in dops}; wr = {o: 1.0 for o in rops}
        sc_d = {o: [0.0, 0] for o in dops}; sc_r = {o: [0.0, 0] for o in rops}
        usage = {o: 0 for o in dops + rops}
        it_best = 0
        self.trace = [best.total] if cfg.record_trace else []

        for t in range(1, I_max+1):
            if cfg.time_limit is not None and time.time() - t_start > cfg.time_limit:
                break
            d = rng.choices(dops, weights=[wd[o] for o in dops])[0]
            r = rng.choices(rops, weights=[wr[o] for o in rops])[0]
            usage[d] += 1; usage[r] += 1
            xp = x.copy()
            removed = self.destroy(d, xp, q)
            self.repair(r, xp, removed)
            score = 0.0
            if xp.total < best.total - 1e-9:
                best = xp.copy(); x = xp; score = cfg.scores[0]; it_best = t
            elif xp.total < x.total - 1e-9:
                x = xp; score = cfg.scores[1]
            elif cfg.sa_acceptance and rng.random() < math.exp(-(xp.total - x.total)/T):
                x = xp; score = cfg.scores[2]
            sc_d[d][0] += score; sc_d[d][1] += 1
            sc_r[r][0] += score; sc_r[r][1] += 1
            if cfg.adaptive_weights and t % cfg.segment == 0:
                for o in dops:
                    if sc_d[o][1] > 0:
                        wd[o] = max(cfg.w_min, (1-cfg.reaction)*wd[o] + cfg.reaction*sc_d[o][0]/sc_d[o][1])
                    sc_d[o] = [0.0, 0]
                for o in rops:
                    if sc_r[o][1] > 0:
                        wr[o] = max(cfg.w_min, (1-cfg.reaction)*wr[o] + cfg.reaction*sc_r[o][0]/sc_r[o][1])
                    sc_r[o] = [0.0, 0]
            T *= gamma
            if cfg.record_trace:
                self.trace.append(best.total)
        self.stats = {"iters": t, "time_s": time.time() - t_start, "f0": f0,
                      "best": best.total, "it_best": it_best,
                      "weights_d": wd, "weights_r": wr, "usage": usage}
        assert best.check_feasible()
        return best


def run_alns(inst: Instance, seed: int = 0, cfg: ALNSConfig = None, x0: Solution = None):
    alg = ALNS_STB(inst, cfg, seed)
    sol = alg.run(x0)
    return sol, alg.stats, alg.trace
