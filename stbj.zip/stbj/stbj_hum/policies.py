"""
Sequential planning policies of Experiment E5 (Section 5.6).

Type-first : for each lot fix the capacity-feasible class with the lowest
             voyage cost S_jk, then run ALNS-STB on berths and sequencing only.
Berth-first: build a berth plan with the smallest feasible class as a
             placeholder (ALNS-STB with classes frozen), then improve the class
             of each lot locally while holding berths (and sequence) fixed.
"""
from __future__ import annotations
from .instance import Instance
from .solution import Solution
from .alns import ALNS_STB, ALNSConfig, run_alns


def type_first(inst: Instance, seed: int = 0, cfg: ALNSConfig = None):
    cfg = cfg or ALNSConfig()
    types = [min(inst.feas_k[j], key=lambda k: inst.S[j][k]) for j in range(inst.N)]
    c = ALNSConfig(**{**cfg.__dict__, "fixed_types": types})
    return run_alns(inst, seed, c)


def _local_type_improvement(sol: Solution, max_pass: int = 5) -> Solution:
    inst = sol.inst
    sol = sol.copy()
    for _ in range(max_pass):
        improved = False
        for j in range(inst.N):
            b = sol.berth[j]
            pos = sol.seq[b].index(j)
            cur_k = sol.ktype[j]
            best_k, best_tot = cur_k, sol.total
            for k in inst.feas_b_given_k[j].keys():
                if k == cur_k or b not in inst.feas_b_given_k[j][k]:
                    continue
                trial = sol.copy()
                trial.remove_lot(j); trial.insert_lot(j, k, b, pos)
                if trial.total < best_tot - 1e-9:
                    best_tot, best_k = trial.total, k
            if best_k != cur_k:
                sol.remove_lot(j); sol.insert_lot(j, best_k, b, pos); improved = True
        if not improved:
            break
    return sol


def berth_first(inst: Instance, seed: int = 0, cfg: ALNSConfig = None):
    cfg = cfg or ALNSConfig()
    placeholder = [min(inst.feas_k[j], key=lambda k: inst.classes[k].C) for j in range(inst.N)]
    c = ALNSConfig(**{**cfg.__dict__, "fixed_types": placeholder})
    sol, stats, _ = run_alns(inst, seed, c)
    sol2 = _local_type_improvement(sol)
    return sol2, stats, []
