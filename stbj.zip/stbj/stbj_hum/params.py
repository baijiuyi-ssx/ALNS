"""
Calibrated parameters of the STBJ-HUM paper (Tables 1 and 2, Section 3.1).
All numbers are copied verbatim from the manuscript.
"""
from dataclasses import dataclass, field
from typing import List
import copy

@dataclass
class VesselClass:
    name: str
    L: float      # length (m)
    draft: float  # draft (m)
    C: float      # deadweight / capacity (t)
    c: float      # daily charter rate (USD/d)
    v: float      # service speed (kn)
    g: float      # daily fuel consumption (t/d)
    sigma: int    # 1 = self-unloading

@dataclass
class Berth:
    name: str
    L: float      # quay length (m)
    D: float      # depth (m)
    tau: int      # 1 = vertical quay (shore unloaders), 0 = sloped berth
    r: float      # handling rate (t/h)
    s: float      # setup time (h)
    beta: float   # service fee rate (USD/h)

# ---- Table 1: vessel classes (Qinhuangdao coal district calibration) ----
VESSEL_CLASSES: List[VesselClass] = [
    VesselClass("Capesize",  292, 18.2, 180000, 22000, 13.5, 45, 0),
    VesselClass("Panamax",   229, 14.2,  82000, 13500, 14.0, 32, 0),
    VesselClass("Supramax",  200, 12.2,  58000, 12500, 14.0, 28, 0),
    VesselClass("Handysize", 180, 10.3,  38000, 10500, 13.5, 22, 0),
    VesselClass("SU-L",      225, 12.0,  70000, 17000, 13.5, 30, 1),
    VesselClass("SU-M",      190, 10.5,  40000, 12000, 13.0, 22, 1),
    VesselClass("SU-S",      140,  8.0,  18000,  8000, 12.0, 14, 1),
]

# ---- Table 2: berths ----
BERTHS: List[Berth] = [
    Berth("Coal5-1",   300, 14.9, 1, 2500, 1.0, 1200),
    Berth("Coal5-2",   310, 19.7, 1, 3000, 0.8, 1400),
    Berth("Coal5-3",   340, 19.7, 1, 3500, 0.8, 1500),
    Berth("Coal5-4",   350, 19.7, 1, 3200, 0.8, 1450),
    Berth("Coal3-301", 340, 17.0, 1, 2000, 1.0, 1000),
    Berth("Coal3-302", 250, 12.5, 1, 1800, 1.2,  950),
    Berth("Coal3-303", 250, 12.5, 1, 1800, 1.2,  950),
    Berth("Slope-A",   230, 12.0, 0, 2000, 1.5,  550),
    Berth("Slope-B",   200,  9.5, 0, 1600, 2.0,  450),
    Berth("Slope-C",   210, 10.5, 0, 1800, 1.5,  500),
]

@dataclass
class CostParams:
    p_fuel: float = 600.0     # USD/t (VLSFO, 2024 average)
    alpha_w: float = 300.0    # anchorage waiting cost USD/h
    pi: float = 1000.0        # demurrage USD/h
    T_max: float = 336.0      # nominal one-week (2 weeks?) planning horizon, h (paper: 336 h)
    charter_scale: float = 1.0
    fuel_scale: float = 1.0
    fee_scale: float = 1.0
    wait_scale: float = 1.0

# ---- Instance generator parameters (Section 5.1) ----
@dataclass
class GenParams:
    W_min: float = 12000.0     # tonnage log-uniform range (t)
    W_max: float = 165000.0
    d_min: float = 400.0       # haul distance uniform (n mile)
    d_max: float = 2500.0
    v_ref: float = 13.5        # reference speed for planned arrival (kn)
    win_start: float = 48.0    # planned arrival window [win_start, win_start+win_len] (h)
    win_len: float = 120.0     # default 48-168 h  => len 120; E6 uses 48 and 72
    r_nominal: float = 1500.0  # nominal handling rate for deadline (t/h)
    slack_min: float = 24.0    # deadline slack uniform (h)
    slack_max: float = 72.0

def layout(name: str) -> List[Berth]:
    """Terminal layouts of Experiment E6."""
    if name == "7V+3S":
        return copy.deepcopy(BERTHS)
    if name == "7V+0S":
        return copy.deepcopy(BERTHS[:7])
    if name == "10V+0S":
        # seven vertical quays plus three additional generic vertical quays.
        # The three extra quays reuse the physical dimensions of the sloped berths
        # but are equipped with shore unloaders (tau=1) and charged at the
        # cheapest vertical-quay fee level (Coal3-302/303) -- see README.
        extra = [Berth("Vert-X1", 230, 12.0, 1, 2000, 1.2, 950),
                 Berth("Vert-X2", 200, 9.5, 1, 1800, 1.2, 950),
                 Berth("Vert-X3", 210, 10.5, 1, 1800, 1.2, 950)]
        return copy.deepcopy(BERTHS[:7]) + extra
    raise ValueError(name)
