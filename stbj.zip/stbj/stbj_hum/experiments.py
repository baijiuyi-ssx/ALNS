"""
Experiment drivers reproducing the protocol of Section 5 (E1-E7).
Every function writes a CSV to results/ and returns a pandas DataFrame.

Protocol (Section 5.1): for each N in {5,8,10,15,20,35,50} two instances
(seeds 1, 2); three seeds per algorithm unless stated otherwise.
"""
from __future__ import annotations
import os, json, time, math, statistics
import pandas as pd
from typing import List, Dict
from scipy.stats import wilcoxon
from .params import GenParams
from .instance import Instance, generate_instance
from .alns import ALNSConfig, VANILLA, run_alns, default_iters
from .milp import solve_milp
from .baselines import simulated_annealing, tabu_search, genetic_algorithm
from .policies import type_first, berth_first

SIZES = [5, 8, 10, 15, 20, 35, 50]
INST_SEEDS = [1, 2]


def ensure_dirs(root: str):
    for d in ("data/instances", "results", "figures"):
        os.makedirs(os.path.join(root, d), exist_ok=True)


def make_instances(root: str, sizes=SIZES, seeds=INST_SEEDS, gp: GenParams = None, tag: str = "") -> Dict[str, Instance]:
    ensure_dirs(root)
    out = {}
    for N in sizes:
        for s in seeds:
            inst = generate_instance(N, s, gp, name=f"N{N}_i{s}{tag}")
            inst.save(os.path.join(root, "data/instances", inst.name + ".json"))
            out[inst.name] = inst
    return out


# ----------------------------------------------------------------------
def E1_validation(root: str, insts: Dict[str, Instance], sizes=(5, 8, 10, 15, 20),
                  n_seeds: int = 5, milp_time: float = 600.0) -> pd.DataFrame:
    rows = []
    for N in sizes:
        for s in INST_SEEDS:
            inst = insts[f"N{N}_i{s}"]
            res = solve_milp(inst, time_limit=milp_time)
            opt = res["objective"]
            costs, times = [], []
            for seed in range(n_seeds):
                sol, st, _ = run_alns(inst, seed)
                costs.append(sol.total); times.append(st["time_s"])
            rows.append({"N": N, "instance": s, "optimum_1e6": opt/1e6 if opt else None,
                         "milp_status": res["message"], "milp_gap": res["mip_gap"],
                         "milp_time_s": res["time_s"], "n_binaries": res["n_binaries"],
                         "alns_best_1e6": min(costs)/1e6,
                         "alns_mean_1e6": statistics.mean(costs)/1e6,
                         "gap_best_pct": 100*(min(costs)-opt)/opt if opt else None,
                         "gap_mean_pct": 100*(statistics.mean(costs)-opt)/opt if opt else None,
                         "alns_mean_time_s": statistics.mean(times)})
            print("E1", rows[-1], flush=True)
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, "results/E1_validation.csv"), index=False)
    return df


# ----------------------------------------------------------------------
def E2_baselines(root: str, insts: Dict[str, Instance], sizes=(10, 15, 20, 35, 50), n_seeds: int = 3, seeds_by_N: dict = None) -> pd.DataFrame:
    rows = []
    for N in sizes:
        for s in INST_SEEDS:
            inst = insts[f"N{N}_i{s}"]
            for seed in range((seeds_by_N or {}).get(N, n_seeds)):
                sol, st, _ = run_alns(inst, seed)
                budget = st["time_s"]
                van, _, _ = run_alns(inst, seed, VANILLA)
                sa, _ = simulated_annealing(inst, budget, seed)
                ga, _ = genetic_algorithm(inst, budget, seed)
                ts, _ = tabu_search(inst, budget, seed)
                f = sol.total
                row = {"N": N, "instance": s, "seed": seed, "time_budget_s": budget,
                       "ALNS_STB": f, "Vanilla_ALNS": van.total, "TS": ts.total, "SA": sa.total, "GA": ga.total}
                for a in ("Vanilla_ALNS", "TS", "SA", "GA"):
                    row[f"gap_{a}_pct"] = 100*(row[a]-f)/f
                rows.append(row); print("E2", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in row.items()}, flush=True)
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, "results/E2_baselines_raw.csv"), index=False)
    # summary table like Table 4
    summ = df.groupby("N")[[f"gap_{a}_pct" for a in ("Vanilla_ALNS", "TS", "SA", "GA")]].mean()
    summ.loc["Mean"] = df[[f"gap_{a}_pct" for a in ("Vanilla_ALNS", "TS", "SA", "GA")]].mean()
    pvals = {}
    for a in ("Vanilla_ALNS", "TS", "SA", "GA"):
        d = df[a] - df["ALNS_STB"]
        pvals[f"gap_{a}_pct"] = wilcoxon(d).pvalue if (d != 0).any() else 1.0
    summ.loc["Wilcoxon_p"] = pd.Series(pvals)
    summ.to_csv(os.path.join(root, "results/E2_baselines_summary.csv"))
    return df


# ----------------------------------------------------------------------
def E3_stability(root: str, insts: Dict[str, Instance], N: int = 35, n_runs: int = 15) -> pd.DataFrame:
    inst = insts[f"N{N}_i1"]
    traces, finals, times = [], [], []
    for seed in range(n_runs):
        sol, st, tr = run_alns(inst, seed, ALNSConfig(record_trace=True))
        traces.append(tr); finals.append(sol.total); times.append(st["time_s"])
        print("E3 seed", seed, round(sol.total/1e6, 4), round(st["time_s"], 1), flush=True)
    L = min(len(t) for t in traces)
    df = pd.DataFrame({f"run{i}": t[:L] for i, t in enumerate(traces)})
    df.index.name = "iteration"
    df.to_csv(os.path.join(root, "results/E3_traces.csv"))
    cv = statistics.stdev(finals)/statistics.mean(finals)*100
    summ = {"N": N, "runs": n_runs, "mean_1e6": statistics.mean(finals)/1e6, "best_1e6": min(finals)/1e6,
            "worst_1e6": max(finals)/1e6, "CV_pct": cv, "worst_to_best_spread_pct": 100*(max(finals)-min(finals))/min(finals),
            "mean_time_s": statistics.mean(times)}
    pd.DataFrame([summ]).to_csv(os.path.join(root, "results/E3_summary.csv"), index=False)
    print("E3", summ)
    return df


# ----------------------------------------------------------------------
ABLATIONS = {
    "w/o HCL (random init)": dict(init="random"),
    "w/o D1": dict(destroy_ops=("D2", "D3", "D4")),
    "w/o D4": dict(destroy_ops=("D1", "D2", "D3")),
    "w/o R3 (regret-2)": dict(repair_ops=("R1", "R2")),
    "w/o SA acceptance": dict(sa_acceptance=False),
    "w/o adaptive weights": dict(adaptive_weights=False),
}

def E4_ablation(root: str, insts: Dict[str, Instance], sizes=(20, 35, 50), n_seeds: int = 3, seeds_by_N: dict = None) -> pd.DataFrame:
    rows = []
    for N in sizes:
        for s in INST_SEEDS:
            inst = insts[f"N{N}_i{s}"]
            for seed in range((seeds_by_N or {}).get(N, n_seeds)):
                full, _, _ = run_alns(inst, seed)
                row = {"N": N, "instance": s, "seed": seed, "full": full.total}
                for name, kw in ABLATIONS.items():
                    sol, _, _ = run_alns(inst, seed, ALNSConfig(**kw))
                    row[name] = sol.total
                rows.append(row); print("E4", N, s, seed, {k: round(100*(v/full.total-1), 3) for k, v in row.items() if k in ABLATIONS}, flush=True)
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, "results/E4_ablation_raw.csv"), index=False)
    summ = []
    for name in ABLATIONS:
        inc = 100*(df[name]/df["full"] - 1)
        r = {"Variant": name}
        for N in sizes:
            r[f"N={N}"] = inc[df["N"] == N].mean()
        r["Mean"] = inc.mean()
        d = df[name] - df["full"]
        r["p"] = wilcoxon(d).pvalue if (d != 0).any() else 1.0
        summ.append(r)
    pd.DataFrame(summ).to_csv(os.path.join(root, "results/E4_ablation_summary.csv"), index=False)
    return df


def E4b_time_to_target(root: str, insts: Dict[str, Instance], sizes=(20, 35, 50), n_seeds: int = 3, tol: float = 0.005) -> pd.DataFrame:
    """Time-to-target study of the construction (Section 5.5)."""
    rows = []
    for N in sizes:
        for s in INST_SEEDS:
            inst = insts[f"N{N}_i{s}"]
            # best-known from the three starts
            runs = {}
            for init in ("hcl", "random", "greedy"):
                runs[init] = [run_alns(inst, seed, ALNSConfig(init=init, record_trace=True)) for seed in range(n_seeds)]
            bk = min(sol.total for v in runs.values() for sol, _, _ in v)
            for init, v in runs.items():
                for seed, (sol, st, tr) in enumerate(v):
                    hit = next((i for i, f in enumerate(tr) if f <= bk*(1+tol)), None)
                    rows.append({"N": N, "instance": s, "seed": seed, "init": init, "f0": st["f0"],
                                 "final": sol.total, "best_known": bk, "iters_to_target": hit})
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, "results/E4b_time_to_target_raw.csv"), index=False)
    summ = df.groupby("init").agg(median_iters_to_target=("iters_to_target", "median"),
                                  mean_final_gap_pct=("final", lambda x: 0))  # placeholder
    summ["mean_final_gap_pct"] = df.assign(g=100*(df["final"]/df["best_known"]-1)).groupby("init")["g"].mean()
    summ.to_csv(os.path.join(root, "results/E4b_time_to_target_summary.csv"))
    print("E4b", summ)
    return df


# ----------------------------------------------------------------------
def E5_joint_vs_sequential(root: str, insts: Dict[str, Instance], sizes=(20, 35, 50), n_seeds: int = 3, seeds_by_N: dict = None, tag: str = "") -> pd.DataFrame:
    """tag="" uses the default instances; tag="_win48" uses the congested 48-h-window instances (supplementary run E5b)."""
    rows = []
    for N in sizes:
        for s in INST_SEEDS:
            inst = insts[f"N{N}_i{s}{tag}"]
            for seed in range((seeds_by_N or {}).get(N, n_seeds)):
                joint, _, _ = run_alns(inst, seed)
                tf, _, _ = type_first(inst, seed)
                bf, _, _ = berth_first(inst, seed)
                jb, tb, bb = joint.breakdown(), tf.breakdown(), bf.breakdown()
                row = {"N": N, "instance": s, "seed": seed,
                       "joint_total": jb["total"], "joint_controllable": jb["controllable"],
                       "typefirst_total": tb["total"], "typefirst_controllable": tb["controllable"],
                       "berthfirst_total": bb["total"], "berthfirst_controllable": bb["controllable"],
                       "typefirst_total_pct": 100*(tb["total"]/jb["total"]-1),
                       "typefirst_ctrl_pct": 100*(tb["controllable"]/jb["controllable"]-1),
                       "berthfirst_total_pct": 100*(bb["total"]/jb["total"]-1),
                       "berthfirst_ctrl_pct": 100*(bb["controllable"]/jb["controllable"]-1),
                       "joint_util": jb["utilization"]}
                rows.append(row); print("E5", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in row.items() if "pct" in k or k in ("N", "instance", "seed")}, flush=True)
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, f"results/E5_sequential{tag}_raw.csv"), index=False)
    cols = ["typefirst_total_pct", "typefirst_ctrl_pct", "berthfirst_total_pct", "berthfirst_ctrl_pct"]
    summ = df.groupby("N")[cols].agg(["mean", "std"])
    summ.to_csv(os.path.join(root, f"results/E5_sequential{tag}_summary.csv"))
    return df


# ----------------------------------------------------------------------
def E6_layouts(root: str, windows=(48, 72), sizes=(20, 35, 50), n_seeds: int = 3, inst_seed: int = 1) -> pd.DataFrame:
    rows = []
    for win in windows:
        for N in sizes:
            gp = GenParams(win_len=float(win))
            base = generate_instance(N, inst_seed, gp, name=f"N{N}_win{win}_i{inst_seed}")
            base.save(os.path.join(root, "data/instances", base.name + ".json"))
            for seed in range(n_seeds):
                r = {"window_h": win, "N": N, "seed": seed}
                for lay in ("7V+3S", "7V+0S", "10V+0S"):
                    inst = base.with_layout(lay)
                    sol, _, _ = run_alns(inst, seed)
                    bd = sol.breakdown()
                    r[f"cost_{lay}"] = bd["total"]; r[f"wait_{lay}"] = bd["total_wait_h"]
                    r[f"ctrl_{lay}"] = bd["controllable"]; r[f"late_{lay}"] = bd["total_late_h"]
                    if lay == "7V+3S":
                        r["util_7V+3S"] = bd["utilization"]; r["lots_on_sloped"] = bd["lots_on_sloped"]
                r["saving_vs_7V0S_pct"] = 100*(1 - r["cost_7V+3S"]/r["cost_7V+0S"])
                r["saving_vs_10V0S_pct"] = 100*(1 - r["cost_7V+3S"]/r["cost_10V+0S"])
                r["wait_reduction_vs_7V0S_pct"] = 100*(1 - r["wait_7V+3S"]/r["wait_7V+0S"]) if r["wait_7V+0S"] > 0 else 0.0
                rows.append(r); print("E6", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}, flush=True)
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, "results/E6_layouts_raw.csv"), index=False)
    summ = df.groupby(["window_h", "N"]).mean(numeric_only=True).drop(columns=["seed"])
    summ.to_csv(os.path.join(root, "results/E6_layouts_summary.csv"))
    return df


# ----------------------------------------------------------------------
def E7_sensitivity(root: str, insts: Dict[str, Instance], N: int = 35, scales=(0.6, 0.8, 1.0, 1.2, 1.4), n_seeds: int = 3) -> pd.DataFrame:
    base = insts[f"N{N}_i1"]
    params = {"Charter rate": "charter_scale", "Bunker price": "fuel_scale",
              "Berth service fee": "fee_scale", "Waiting cost": "wait_scale"}
    base_cost = statistics.mean(run_alns(base, seed)[0].total for seed in range(n_seeds))
    rows = []
    for pname, key in params.items():
        for sc in scales:
            if sc == 1.0:
                cost = base_cost
            else:
                inst = base.with_cost(**{key: sc})
                cost = statistics.mean(run_alns(inst, seed)[0].total for seed in range(n_seeds))
            rows.append({"parameter": pname, "scale": sc, "cost": cost, "change_pct": 100*(cost/base_cost-1)})
            print("E7", rows[-1], flush=True)
    df = pd.DataFrame(rows); df.to_csv(os.path.join(root, "results/E7_sensitivity_raw.csv"), index=False)
    piv = df.pivot(index="parameter", columns="scale", values="change_pct")
    piv["elasticity_at_+40%"] = piv[1.4]/40.0
    piv.to_csv(os.path.join(root, "results/E7_sensitivity_summary.csv"))
    return df
