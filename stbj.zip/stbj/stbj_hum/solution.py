"""
Solution encoding and the semi-active decoder (Section 3.2, "structural remarks").

A solution is fully described by
    ktype[j]  chosen vessel class of lot j
    berth[j]  chosen berth of lot j
    seq[b]    ordered list of lots served at berth b
Given these, the semi-active schedule (start every lot as early as its arrival
and its predecessor permit) is optimal because every cost component is
non-decreasing in s_j and e_j.  The decoder therefore evaluates a solution in
O(N) with one left-to-right pass per berth.

Cost components (Section 3.1):
   (i)  voyage cost           S[j][k]                 fixed by k
   (ii) in-port charter cost  c_k/24 * (e_j - A_jk)   schedule dependent
   (iii) anchorage waiting    alpha_w * w_j
   (iv) demurrage             pi * max(0, e_j - D_j)
   (v)  berth service fee     U[j][b]                 fixed by b
"controllable cost" = (ii)+(iii)+(iv)+(v)  (Section 3.2)
"""
from __future__ import annotations
import copy
from typing import List, Dict, Tuple
from .instance import Instance


class Solution:
    __slots__ = ("inst", "ktype", "berth", "seq", "start", "end", "wait",
                 "late", "berth_cost", "berth_wait", "lot_cost", "total")

    def __init__(self, inst: Instance):
        self.inst = inst
        N, B = inst.N, inst.B
        self.ktype = [-1]*N
        self.berth = [-1]*N
        self.seq: List[List[int]] = [[] for _ in range(B)]
        self.start = [0.0]*N
        self.end = [0.0]*N
        self.wait = [0.0]*N
        self.late = [0.0]*N
        self.lot_cost = [0.0]*N
        self.berth_cost = [0.0]*B
        self.berth_wait = [0.0]*B
        self.total = float("inf")

    # ------------------------------------------------------------------
    def copy(self) -> "Solution":
        s = Solution.__new__(Solution)
        s.inst = self.inst
        s.ktype = self.ktype[:]
        s.berth = self.berth[:]
        s.seq = [q[:] for q in self.seq]
        s.start = self.start[:]; s.end = self.end[:]
        s.wait = self.wait[:]; s.late = self.late[:]
        s.lot_cost = self.lot_cost[:]
        s.berth_cost = self.berth_cost[:]
        s.berth_wait = self.berth_wait[:]
        s.total = self.total
        return s

    # ------------------------------------------------------------------
    def decode_berth(self, b: int) -> float:
        """Semi-active decode of berth b; stores times and returns berth cost."""
        inst = self.inst
        A, S, T, U, c_h = inst.A, inst.S, inst.T, inst.U, inst.c_h
        lots = inst.lots
        aw, pi = inst.alpha_w, inst.pi
        prev_end = -1e18
        cost = 0.0
        wsum = 0.0
        for j in self.seq[b]:
            k = self.ktype[j]
            a = A[j][k]
            s = a if a > prev_end else prev_end
            e = s + T[j][b]
            w = s - a
            l = e - lots[j].D
            if l < 0.0:
                l = 0.0
            cj = S[j][k] + U[j][b] + c_h[k]*(e - a) + aw*w + pi*l
            self.start[j] = s; self.end[j] = e; self.wait[j] = w; self.late[j] = l
            self.lot_cost[j] = cj
            cost += cj
            wsum += w
            prev_end = e
        self.berth_cost[b] = cost
        self.berth_wait[b] = wsum
        return cost

    def decode(self) -> float:
        tot = 0.0
        for b in range(self.inst.B):
            tot += self.decode_berth(b)
        self.total = tot
        return tot

    # ------------------------------------------------------------------
    def eval_berth_sequence(self, b: int, seq: List[int], ktype_override: Dict[int, int] = None) -> float:
        """Cost of berth b if it served `seq` (no state change)."""
        inst = self.inst
        A, S, T, U, c_h = inst.A, inst.S, inst.T, inst.U, inst.c_h
        lots = inst.lots
        aw, pi = inst.alpha_w, inst.pi
        prev_end = -1e18
        cost = 0.0
        kt = self.ktype
        for j in seq:
            k = ktype_override[j] if (ktype_override and j in ktype_override) else kt[j]
            a = A[j][k]
            s = a if a > prev_end else prev_end
            e = s + T[j][b]
            l = e - lots[j].D
            if l < 0.0:
                l = 0.0
            cost += S[j][k] + U[j][b] + c_h[k]*(e - a) + aw*(s - a) + pi*l
            prev_end = e
        return cost

    def insertion_delta(self, j: int, k: int, b: int, pos: int) -> float:
        """Cost increase of inserting lot j (class k) at position pos of berth b."""
        seq = self.seq[b]
        new_seq = seq[:pos] + [j] + seq[pos:]
        return self.eval_berth_sequence(b, new_seq, {j: k}) - self.berth_cost[b]

    # ------------------------------------------------------------------
    def remove_lot(self, j: int):
        b = self.berth[j]
        self.seq[b].remove(j)
        self.berth[j] = -1
        self.ktype[j] = -1
        old = self.berth_cost[b]
        self.decode_berth(b)
        self.total += self.berth_cost[b] - old

    def insert_lot(self, j: int, k: int, b: int, pos: int):
        self.ktype[j] = k
        self.berth[j] = b
        self.seq[b].insert(pos, j)
        old = self.berth_cost[b]
        self.decode_berth(b)
        self.total += self.berth_cost[b] - old

    # ------------------------------------------------------------------
    def is_complete(self) -> bool:
        return all(b >= 0 for b in self.berth)

    def check_feasible(self) -> bool:
        inst = self.inst
        for j in range(inst.N):
            if (self.ktype[j], self.berth[j]) not in inst.Phi[j]:
                return False
        seen = sorted(j for q in self.seq for j in q)
        return seen == list(range(inst.N))

    def breakdown(self) -> Dict[str, float]:
        """Cost decomposition (i)-(v), controllable cost, waiting, utilization."""
        inst = self.inst
        voy = fee = inport = waitc = dem = 0.0
        for j in range(inst.N):
            k, b = self.ktype[j], self.berth[j]
            voy += inst.S[j][k]
            fee += inst.U[j][b]
            inport += inst.c_h[k]*(self.end[j] - inst.A[j][k])
            waitc += inst.alpha_w*self.wait[j]
            dem += inst.pi*self.late[j]
        total = voy + fee + inport + waitc + dem
        first = min(inst.A[j][self.ktype[j]] for j in range(inst.N))
        last = max(self.end)
        busy = sum(inst.T[j][self.berth[j]] for j in range(inst.N))
        util = busy/(inst.B*(last - first)) if last > first else 0.0
        return {"total": total, "voyage": voy, "inport_charter": inport,
                "waiting_cost": waitc, "demurrage": dem, "service_fee": fee,
                "controllable": total - voy, "total_wait_h": sum(self.wait),
                "total_late_h": sum(self.late), "utilization": util,
                "lots_on_sloped": sum(1 for j in range(inst.N) if inst.berths[self.berth[j]].tau == 0),
                "makespan": last}

    def to_dict(self):
        inst = self.inst
        return {"instance": inst.name, "total": self.total, **self.breakdown(),
                "assignment": [{"lot": j, "class": inst.classes[self.ktype[j]].name,
                                "berth": inst.berths[self.berth[j]].name,
                                "arrival": inst.A[j][self.ktype[j]], "start": self.start[j],
                                "end": self.end[j], "wait": self.wait[j], "late": self.late[j]}
                               for j in range(inst.N)]}
