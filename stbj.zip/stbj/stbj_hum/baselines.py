"""
Baselines of Experiment E2 (Section 5.3), all implemented on the identical
encoding (ktype, berth, seq) and semi-active decoder, so that differences
reflect search strategy rather than implementation.

  * vanilla ALNS   : alns.VANILLA config (random start, D2/D3 destroy,
                     R1/R3 repair, adaptive weights, SA acceptance)
  * SA             : simulated annealing over single-move mutations
  * GA             : genetic algorithm with order-preserving (OX) crossover on
                     the priority permutation and uniform crossover on the
                     class/berth vectors
  * TS             : tabu search over the same single-move set (sampled
                     neighbourhood, attribute-based tabu list)

Single moves (shared by SA and TS):
  m1 change class of a lot        (berth kept if still compatible, else re-drawn)
  m2 move a lot to another berth/position
  m3 swap the positions of two lots on the same berth
Every baseline receives a wall-clock budget equal to the ALNS-STB run.
"""
from __future__ import annotations
import math, random, time
from typing import List, Tuple
from .instance import Instance
from .solution import Solution
from .alns import ALNS_STB, ALNSConfig


# ----------------------------------------------------------------------
def random_solution(inst: Instance, rng: random.Random) -> Solution:
    alg = ALNS_STB(inst, ALNSConfig(init="random"), seed=rng.randrange(10**9))
    return alg.construct("random")


def apply_move(sol: Solution, rng: random.Random, inst: Instance) -> Tuple[Solution, tuple]:
    """Return a neighbour and a move attribute (for tabu)."""
    nb = sol.copy()
    N = inst.N
    j = rng.randrange(N)
    mtype = rng.random()
    if mtype < 0.35:  # m1 change class
        ks = [k for k in inst.feas_k[j] if k != nb.ktype[j]]
        if not ks:
            return apply_move(sol, rng, inst)
        k = rng.choice(ks)
        b = nb.berth[j]
        pos = nb.seq[b].index(j)
        nb.remove_lot(j)
        if b not in inst.feas_b_given_k[j][k]:
            b = rng.choice(inst.feas_b_given_k[j][k])
            pos = rng.randint(0, len(nb.seq[b]))
        nb.insert_lot(j, k, b, pos)
        return nb, ("k", j, k)
    elif mtype < 0.75:  # m2 relocate to another berth / position
        k = nb.ktype[j]
        nb.remove_lot(j)
        b = rng.choice(inst.feas_b_given_k[j][k])
        pos = rng.randint(0, len(nb.seq[b]))
        nb.insert_lot(j, k, b, pos)
        return nb, ("b", j, b, pos)
    else:  # m3 swap two lots on the same berth
        b = nb.berth[j]
        seq = nb.seq[b]
        if len(seq) < 2:
            return apply_move(sol, rng, inst)
        i1 = seq.index(j); i2 = rng.randrange(len(seq))
        if i1 == i2:
            i2 = (i2 + 1) % len(seq)
        seq[i1], seq[i2] = seq[i2], seq[i1]
        old = nb.berth_cost[b]; nb.decode_berth(b); nb.total += nb.berth_cost[b] - old
        return nb, ("s", b, min(seq[i1], seq[i2]), max(seq[i1], seq[i2]))


# ----------------------------------------------------------------------
def simulated_annealing(inst: Instance, time_budget: float, seed: int = 0,
                        T0_frac: float = 0.01, Tend_frac: float = 1e-4) -> Tuple[Solution, dict]:
    rng = random.Random(seed)
    x = random_solution(inst, rng)
    best = x.copy()
    f0 = x.total
    T = T0_frac*f0/math.log(2.0); T_end = Tend_frac*f0
    t0 = time.time(); it = 0
    # geometric cooling calibrated on elapsed time
    while True:
        el = time.time() - t0
        if el > time_budget:
            break
        frac = el/time_budget
        T = T0_frac*f0/math.log(2.0) * (T_end/(T0_frac*f0/math.log(2.0)))**frac
        nb, _ = apply_move(x, rng, inst)
        delta = nb.total - x.total
        if delta < 0 or rng.random() < math.exp(-delta/T):
            x = nb
            if x.total < best.total - 1e-9:
                best = x.copy()
        it += 1
    return best, {"iters": it, "time_s": time.time() - t0}


# ----------------------------------------------------------------------
def tabu_search(inst: Instance, time_budget: float, seed: int = 0,
                n_neigh: int = 30, tenure: int = 15) -> Tuple[Solution, dict]:
    rng = random.Random(seed)
    x = random_solution(inst, rng)
    best = x.copy()
    tabu = {}
    t0 = time.time(); it = 0
    while time.time() - t0 < time_budget:
        it += 1
        cand = []
        for _ in range(n_neigh):
            nb, attr = apply_move(x, rng, inst)
            cand.append((nb.total, nb, attr))
        cand.sort(key=lambda c: c[0])
        chosen = None
        for f, nb, attr in cand:
            if tabu.get(attr, -1) > it and f >= best.total - 1e-9:   # aspiration
                continue
            chosen = (nb, attr); break
        if chosen is None:
            chosen = (cand[0][1], cand[0][2])
        x, attr = chosen
        tabu[attr] = it + tenure
        if x.total < best.total - 1e-9:
            best = x.copy()
    return best, {"iters": it, "time_s": time.time() - t0}


# ----------------------------------------------------------------------
class _Chrom:
    __slots__ = ("k", "b", "perm", "fit", "sol")


def _decode_chrom(inst: Instance, ch: "_Chrom") -> Solution:
    sol = Solution(inst)
    sol.ktype = ch.k[:]; sol.berth = ch.b[:]
    rank = {j: i for i, j in enumerate(ch.perm)}
    for b in range(inst.B):
        lots = [j for j in range(inst.N) if ch.b[j] == b]
        lots.sort(key=lambda j: rank[j])
        sol.seq[b] = lots
    sol.decode()
    return sol


def genetic_algorithm(inst: Instance, time_budget: float, seed: int = 0,
                      pop_size: int = 60, p_mut: float = 0.15, elite: int = 4) -> Tuple[Solution, dict]:
    rng = random.Random(seed)
    N = inst.N

    def random_chrom():
        ch = _Chrom()
        ch.k = [rng.choice(inst.feas_k[j]) for j in range(N)]
        ch.b = [rng.choice(inst.feas_b_given_k[j][ch.k[j]]) for j in range(N)]
        perm = list(range(N)); perm.sort(key=lambda j: inst.A[j][ch.k[j]] + rng.uniform(-24, 24))
        ch.perm = perm
        return ch

    def evaluate(ch):
        ch.sol = _decode_chrom(inst, ch); ch.fit = ch.sol.total

    def repair_kb(ch):
        for j in range(N):
            if ch.k[j] not in inst.feas_k[j]:
                ch.k[j] = rng.choice(inst.feas_k[j])
            if ch.b[j] not in inst.feas_b_given_k[j][ch.k[j]]:
                ch.b[j] = rng.choice(inst.feas_b_given_k[j][ch.k[j]])

    def ox(p1, p2):
        a, b = sorted(rng.sample(range(N), 2))
        child = [-1]*N
        child[a:b+1] = p1[a:b+1]
        fill = [g for g in p2 if g not in set(child[a:b+1])]
        idx = 0
        for i in range(N):
            if child[i] == -1:
                child[i] = fill[idx]; idx += 1
        return child

    def crossover(c1, c2):
        ch = _Chrom()
        ch.k = [c1.k[j] if rng.random() < 0.5 else c2.k[j] for j in range(N)]
        ch.b = [c1.b[j] if rng.random() < 0.5 else c2.b[j] for j in range(N)]
        ch.perm = ox(c1.perm, c2.perm)
        repair_kb(ch)
        return ch

    def mutate(ch):
        for j in range(N):
            if rng.random() < p_mut/ N * 3:
                ch.k[j] = rng.choice(inst.feas_k[j])
            if rng.random() < p_mut/ N * 3:
                ch.b[j] = rng.choice(inst.feas_b_given_k[j][ch.k[j]])
        if rng.random() < p_mut:
            i, j = rng.sample(range(N), 2)
            ch.perm[i], ch.perm[j] = ch.perm[j], ch.perm[i]
        repair_kb(ch)

    def tournament(pop):
        a, b = rng.sample(pop, 2)
        return a if a.fit < b.fit else b

    t0 = time.time()
    pop = [random_chrom() for _ in range(pop_size)]
    for ch in pop:
        evaluate(ch)
    pop.sort(key=lambda c: c.fit)
    gen = 0
    while time.time() - t0 < time_budget:
        gen += 1
        new = pop[:elite]
        while len(new) < pop_size:
            ch = crossover(tournament(pop), tournament(pop))
            mutate(ch); evaluate(ch); new.append(ch)
        new.sort(key=lambda c: c.fit)
        pop = new
    best = pop[0].sol
    return best, {"generations": gen, "time_s": time.time() - t0}
