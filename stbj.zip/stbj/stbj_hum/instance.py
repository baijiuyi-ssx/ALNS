"""
Instance definition and generator for STBJ-HUM (Section 3.1 and Section 5.1).

An instance holds the lots, the vessel classes, the berths, the cost parameters
and all derived quantities of Eq. (1)-(3):
    A[j][k]  arrival time of lot j under class k          (Eq. 1)
    S[j][k]  laden-leg voyage cost of lot j under class k (Eq. 2)
    T[j][b]  service duration of lot j at berth b         W_j/r_b + s_b
    U[j][b]  berth service fee of lot j at berth b        beta_b * T[j][b]
    Phi[j]   compatibility-feasible (k, b) pairs           (Eq. 3)
"""
from __future__ import annotations
import json, math, random
from dataclasses import dataclass, field, asdict
from typing import List, Tuple, Dict, Optional
from .params import (VesselClass, Berth, CostParams, GenParams,
                     VESSEL_CLASSES, BERTHS, layout)


@dataclass
class Lot:
    W: float   # tonnage (t)
    d: float   # haul distance (n mile)
    R: float   # cargo-ready time (h)
    D: float   # contractual discharge deadline (h)


class Instance:
    def __init__(self, name: str, lots: List[Lot],
                 classes: Optional[List[VesselClass]] = None,
                 berths: Optional[List[Berth]] = None,
                 cost: Optional[CostParams] = None,
                 meta: Optional[dict] = None):
        self.name = name
        self.lots = lots
        self.classes = classes if classes is not None else list(VESSEL_CLASSES)
        self.berths = berths if berths is not None else list(BERTHS)
        self.cost = cost if cost is not None else CostParams()
        self.meta = meta or {}
        self.build()

    # ------------------------------------------------------------------
    @property
    def N(self): return len(self.lots)
    @property
    def K(self): return len(self.classes)
    @property
    def B(self): return len(self.berths)

    def build(self):
        """Pre-compute A, S, T, U, Phi (Eq. 1-3) under the current cost scaling."""
        cp = self.cost
        N, K, B = self.N, self.K, self.B
        self.A = [[0.0]*K for _ in range(N)]
        self.S = [[0.0]*K for _ in range(N)]
        self.T = [[0.0]*B for _ in range(N)]
        self.U = [[0.0]*B for _ in range(N)]
        self.Phi: List[List[Tuple[int, int]]] = []
        self.c_h = [cp.charter_scale*k.c/24.0 for k in self.classes]  # hourly charter rate
        for j, lot in enumerate(self.lots):
            for k, cl in enumerate(self.classes):
                self.A[j][k] = lot.R + lot.d/cl.v
                self.S[j][k] = lot.d/(24.0*cl.v) * (cp.charter_scale*cl.c + cl.g*cp.fuel_scale*cp.p_fuel)
            for b, be in enumerate(self.berths):
                self.T[j][b] = lot.W/be.r + be.s
                self.U[j][b] = cp.fee_scale*be.beta*self.T[j][b]
            pairs = []
            for k, cl in enumerate(self.classes):
                if cl.C < lot.W:
                    continue
                for b, be in enumerate(self.berths):
                    if cl.L <= be.L and cl.draft <= be.D and (be.tau == 1 or cl.sigma == 1):
                        pairs.append((k, b))
            if not pairs:
                raise ValueError(f"lot {j} has no feasible (class, berth) pair")
            self.Phi.append(pairs)
        # feasible classes / berths per lot, and berths feasible for (j,k)
        self.feas_k = [sorted({k for k, _ in P}) for P in self.Phi]
        self.feas_b_given_k = [{k: [b for kk, b in P if kk == k] for k in fk}
                               for P, fk in zip(self.Phi, self.feas_k)]
        # effective horizon bound for the big-M (Section 3.2 uses T_max + 1)
        max_arr = max(self.A[j][k] for j in range(N) for k in self.feas_k[j])
        max_serv = sum(max(self.T[j]) for j in range(N))
        self.T_bound = max(cp.T_max, math.ceil(max_arr + max_serv + 1.0))
        self.alpha_w = cp.wait_scale*cp.alpha_w
        self.pi = cp.pi

    # ------------------------------------------------------------------
    def to_dict(self):
        return {"name": self.name,
                "lots": [asdict(l) for l in self.lots],
                "classes": [asdict(c) for c in self.classes],
                "berths": [asdict(b) for b in self.berths],
                "cost": asdict(self.cost),
                "meta": self.meta}

    def save(self, path: str):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=1)

    @staticmethod
    def load(path: str) -> "Instance":
        with open(path) as f:
            d = json.load(f)
        return Instance(d["name"], [Lot(**l) for l in d["lots"]],
                        [VesselClass(**c) for c in d["classes"]],
                        [Berth(**b) for b in d["berths"]],
                        CostParams(**d["cost"]), d.get("meta", {}))

    def with_cost(self, **kw) -> "Instance":
        """Copy with scaled cost parameters (Experiment E7)."""
        cp = CostParams(**{**asdict(self.cost), **kw})
        return Instance(self.name, self.lots, self.classes, self.berths, cp, dict(self.meta))

    def with_layout(self, name: str) -> "Instance":
        """Copy with a different terminal layout (Experiment E6)."""
        return Instance(self.name, self.lots, self.classes, layout(name), self.cost,
                        {**self.meta, "layout": name})


# ----------------------------------------------------------------------
def generate_instance(N: int, seed: int, gp: Optional[GenParams] = None,
                      name: Optional[str] = None,
                      classes: Optional[List[VesselClass]] = None,
                      berths: Optional[List[Berth]] = None) -> Instance:
    """
    Instance generator following Section 5.1 literally:
      * tonnage       log-uniform on [12,000, 165,000] t
      * haul distance uniform on [400, 2,500] n mile
      * planned arrival at the 13.5-kn reference speed uniform on the arrival
        window (default 48-168 h); cargo-ready time backed out: R = P - d/13.5
      * deadline = slowest-class arrival + nominal service at 1,500 t/h
                   + uniform slack of 24-72 h
    Implementation note: backing out R may give negative cargo-ready times for
    distant origins (the cargo was ready before the planning epoch).  To keep
    all times non-negative (needed by the MILP bounds), the time origin is
    shifted so that the earliest cargo-ready time is 0; this is an equivalent
    instance because all costs depend on time differences only.
    """
    gp = gp or GenParams()
    rng = random.Random(seed)
    classes = classes or list(VESSEL_CLASSES)
    berths = berths or list(BERTHS)
    v_slow = min(c.v for c in classes)
    lots = []
    for _ in range(N):
        W = math.exp(rng.uniform(math.log(gp.W_min), math.log(gp.W_max)))
        d = rng.uniform(gp.d_min, gp.d_max)
        P = rng.uniform(gp.win_start, gp.win_start + gp.win_len)
        R = P - d/gp.v_ref
        lots.append(Lot(W=round(W, 1), d=round(d, 1), R=R, D=0.0))
    shift = -min(l.R for l in lots)
    if shift < 0:
        shift = 0.0
    for l in lots:
        l.R = round(l.R + shift, 2)
        l.D = round(l.R + l.d/v_slow + l.W/gp.r_nominal + rng.uniform(gp.slack_min, gp.slack_max), 2)
    name = name or f"N{N}_s{seed}"
    meta = {"N": N, "seed": seed, "gen": asdict(gp), "time_shift_h": round(shift, 2)}
    return Instance(name, lots, classes, berths, CostParams(), meta)
